#include <string.h>
char *crlf_to_lf(char *line_with_crlf)
{
	/* pour éviter les warnings de variable non utilisée */
	return line_with_crlf;
}

char *lf_to_crlf(char *line_with_lf)
{
	/* pour éviter les warnings de variable non utilisée */
	return line_with_lf;
}
